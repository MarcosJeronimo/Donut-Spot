SELECT TOP (1000) [ID_Cliente]
      ,[Nome]
      ,[Email]
      ,[Telefone]
      ,[Morada]
      ,[Concelho]
      ,[Contribuinte]
      ,[Tipo_Cliente]
  FROM [DonutSpot].[dspot].[DIM_Cliente]

TRUNCATE TABLE dspot.DIM_Cliente;

ALTER TABLE dspot.DIM_Cliente
ALTER COLUMN ID_Cliente VARCHAR(10) PRIMARY KEY NOT NULL;


INSERT INTO dspot.DIM_Cliente (ID_Cliente, Nome, Email, Telefone, Morada, Concelho, Contribuinte, TIPO_CLIENTE)
VALUES 
	('C1', 'Ana Silva', 'ana.silva@gmail.com', '912345678', 'Rua do Sol 10', 'Lisboa', '200000001', 'Standard'),
('C2', 'Tech Solutions Lda', 'tech.solutions@yahoo.com', '917654321', 'Avenida das Flores 22', 'Porto', '200000002', 'Premium'),
('C3', 'Pedro Santos', 'pedro.santos@hotmail.com', '912345679', 'Travessa do Parque 15', 'Coimbra', '200000003', 'Standard'),
('C4', 'Joana Costa', 'joana.costa@gmail.com', '912345680', 'Rua da Paz 8', 'Braga', '200000004', 'Standard'),
('C5', 'Global Systems SA', 'global.systems@gmail.com', '912345681', 'Avenida do Mar 18', 'Faro', '200000005', 'Premium'),
('C6', 'Carlos Oliveira', 'carlos.oliveira@yahoo.com', '912345682', 'Rua dos Pinhais 33', '�vora', '200000006', 'Standard'),
('C7', 'Marta Ribeiro', 'marta.ribeiro@hotmail.com', '912345683', 'Pra�a das �rvores 3', 'Set�bal', '200000007', 'Standard'),
('C8', 'Innovation Corp', 'innovation.corp@gmail.com', '912345684', 'Rua Nova 5', 'Viseu', '200000008', 'Premium'),
('C9', 'Andr� Nogueira', 'andre.nogueira@yahoo.com', '912345685', 'Avenida Central 20', 'Leiria', '200000009', 'Standard'),
('C10', 'Bright Horizons SA', 'bright.horizons@hotmail.com', '912345686', 'Rua da Alegria 12', 'Aveiro', '200000010', 'Premium'),
('C11', 'Tiago Carvalho', 'tiago.carvalho@gmail.com', '912345687', 'Travessa das Colinas 7', 'Santar�m', '200000011', 'Standard'),
('C12', 'Beatriz Lopes', 'beatriz.lopes@yahoo.com', '912345688', 'Rua dos Cravos 9', 'Beja', '200000012', 'Standard'),
('C13', 'Prime Networks Lda', 'prime.networks@gmail.com', '912345689', 'Avenida do Norte 25', 'Portim�o', '200000013', 'Premium'),
('C14', 'Helena Mendes', 'helena.mendes@hotmail.com', '912345690', 'Rua das Palmeiras 4', 'Cascais', '200000014', 'Standard'),
('C15', 'Rui Ferreira', 'rui.ferreira@gmail.com', '912345691', 'Pra�a do Com�rcio 1', 'Guimar�es', '200000015', 'Standard'),
('C16', 'Nova Ventures SA', 'nova.ventures@yahoo.com', '912345692', 'Rua das Fontes 6', 'Almada', '200000016', 'Premium'),
('C17', 'F�bio Sim�es', 'fabio.simoes@hotmail.com', '912345693', 'Travessa dos L�rios 14', 'Barreiro', '200000017', 'Standard'),
('C18', 'Joana Marques', 'joana.marques@gmail.com', '912345694', 'Rua da Esperan�a 21', 'Funchal', '200000018', 'Standard'),
('C19', 'Green Tech Lda', 'green.tech@gmail.com', '912345695', 'Avenida das Oliveiras 30', 'Angra do Hero�smo', '200000019', 'Premium'),
('C20', 'In�s Barros', 'ines.barros@yahoo.com', '912345696', 'Rua do Miradouro 15', 'Vila Nova de Gaia', '200000020', 'Standard'),
('C21', 'Miguel Teixeira', 'miguel.teixeira@hotmail.com', '912345697', 'Rua dos Campos 8', 'Oeiras', '200000021', 'Standard'),
('C22', 'Future Solutions Lda', 'future.solutions@gmail.com', '912345698', 'Travessa do Sol 10', 'P�voa de Varzim', '200000022', 'Premium'),
('C23', 'Rafael Neves', 'rafael.neves@yahoo.com', '912345699', 'Rua do Norte 16', 'Loul�', '200000023', 'Standard'),
('C24', 'Smart Energy SA', 'smart.energy@hotmail.com', '912345700', 'Avenida do Sul 11', 'Amadora', '200000024', 'Premium'),
('C25', 'Hugo Ara�jo', 'hugo.araujo@gmail.com', '912345701', 'Rua das Estrelas 3', 'Montijo', '200000025', 'Standard'),
('C26', 'Catarina Tavares', 'catarina.tavares@yahoo.com', '912345702', 'Travessa do Campo 12', 'Seixal', '200000026', 'Standard'),
('C27', 'Eduardo Moreira', 'eduardo.moreira@hotmail.com', '912345703', 'Pra�a da Liberdade 7', 'Peniche', '200000027', 'Standard'),
('C28', 'Filipa Matos', 'filipa.matos@gmail.com', '912345704', 'Rua dos Sonhos 18', 'Torres Vedras', '200000028', 'Standard'),
('C29', 'Tech World Lda', 'tech.world@yahoo.com', '912345705', 'Avenida dos Pinheiros 14', 'Sintra', '200000029', 'Premium'),
('C30', 'Cl�udia Monteiro', 'claudia.monteiro@hotmail.com', '912345706', 'Rua do Horizonte 19', 'Tomar', '200000030', 'Standard'),
('C31', 'Daniel Cunha', 'daniel.cunha@gmail.com', '912345707', 'Travessa das Rosas 22', 'Chaves', '200000031', 'Standard'),
('C32', 'Innovate Group SA', 'innovate.group@hotmail.com', '912345708', 'Rua da Luz 23', 'Fafe', '200000032', 'Premium'),
('C33', 'Gon�alo Rodrigues', 'goncalo.rodrigues@gmail.com', '912345709', 'Avenida das �guas 31', 'Covilh�', '200000033', 'Standard'),
('C34', 'Rita Faria', 'rita.faria@yahoo.com', '912345710', 'Rua das Pedras 20', 'Albufeira', '200000034', 'Standard'),
('C35', 'Fernando Pires', 'fernando.pires@hotmail.com', '912345711', 'Pra�a do Girassol 9', 'Trofa', '200000035', 'Standard'),
('C36', 'Blue Horizons Lda', 'blue.horizons@gmail.com', '912345712', 'Rua das Andorinhas 25', 'Lagos', '200000036', 'Premium'),
('C37', 'Henrique Pinto', 'henrique.pinto@yahoo.com', '912345713', 'Travessa do Lago 16', 'Alcoba�a', '200000037', 'Standard'),
('C38', 'Sara Vasconcelos', 'sara.vasconcelos@hotmail.com', '912345714', 'Rua do Vento 13', 'Sines', '200000038', 'Standard'),
('C39', 'Bruno Batista', 'bruno.batista@gmail.com', '912345715', 'Avenida dos Cravos 27', 'Pombal', '200000039', 'Standard'),
('C40', 'Raquel Dias', 'raquel.dias@yahoo.com', '912345716', 'Rua da Brisa 17', 'Lourinh�', '200000040', 'Standard'),
('C41', 'Alexandre Leite', 'alexandre.leite@hotmail.com', '912345717', 'Rua Nova do Sul 22', 'Maia', '200000041', 'Standard'),
('C42', 'NextGen Solutions Lda', 'nextgen.solutions@gmail.com', '912345718', 'Travessa da Praia 18', 'Ovar', '200000042', 'Premium'),
('C43', 'Paulo Almeida', 'paulo.almeida@yahoo.com', '912345719', 'Rua dos Montes 6', '�vora', '200000043', 'Standard'),
('C44', 'C�lia Sousa', 'celia.sousa@hotmail.com', '912345720', 'Avenida do Sol Nascente 5', 'Caldas da Rainha', '200000044', 'Standard'),
('C45', 'Jorge Magalh�es', 'jorge.magalhaes@gmail.com', '912345721', 'Rua das Laranjeiras 12', 'Oliveira do Hospital', '200000045', 'Standard'),
('C46', 'Rosa Ventura', 'rosa.ventura@yahoo.com', '912345722', 'Pra�a do Castelo 21', 'Our�m', '200000046', 'Standard'),
('C47', 'Ant�nio Matias', 'antonio.matias@hotmail.com', '912345723', 'Travessa da Torre 3', 'Aljezur', '200000047', 'Standard'),
('C48', 'Mariana Gon�alves', 'mariana.goncalves@gmail.com', '912345724', 'Rua das Magn�lias 15', 'Celorico da Beira', '200000048', 'Standard'),
('C49', 'Francisco Coelho', 'francisco.coelho@yahoo.com', '912345725', 'Avenida da Vit�ria 19', 'Sabugal', '200000049', 'Standard'),
('C50', 'Bright Path Lda', 'bright.path@hotmail.com', '912345726', 'Rua do Castelo 4', 'Montemor-o-Novo', '200000050', 'Premium');

DROP TABLE dspot.DIM_Cliente


