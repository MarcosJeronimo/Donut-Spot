CREATE TABLE dspot.DIM_Canal_Venda(
	ID_Canal_Local VARCHAR(10) PRIMARY KEY NOT NULL,
	Canal_Venda VARCHAR(100) NOT NULL,
	ID_Local VARCHAR(10) NOT NULL,
	FOREIGN KEY (ID_Local) REFERENCES dspot.DIM_Local_Venda(ID_Local)
);

ALTER TABLE dspot.DIM_Canal_Venda
ALTER COLUMN ID_Local VARCHAR(10) NULL;


INSERT INTO dspot.DIM_Canal_Venda (ID_Canal_Local, Canal_Venda, ID_Local)
VALUES 
	('CV1', 'Online', NULL),
	('CV2', 'F�sico', 'LV1'),
	('CV3', 'F�sico', 'LV2'),
	('CV4', 'F�sico', 'LV3'),
	('CV5', 'F�sico', 'LV4');


