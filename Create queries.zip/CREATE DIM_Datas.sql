DROP TABLE IF EXISTS dspot.DIM_Dates;

CREATE TABLE dspot.DIM_Datas (
    DateKey DATE PRIMARY KEY NOT NULL,
    Year INT,
    Month INT,
    Day INT,
    DayOfWeek INT,
    DayOfWeekName VARCHAR(20),
    MonthName VARCHAR(20),
    Quarter INT,
    IsWeekend BIT
);

DECLARE @StartDate DATE = '2023-01-01';
DECLARE @EndDate DATE = '2025-02-28';  -- Adjusted end date

WHILE @StartDate <= @EndDate
BEGIN
    INSERT INTO dspot.DIM_Datas (
        DateKey, Year, Month, Day, DayOfWeek, DayOfWeekName, MonthName, Quarter, IsWeekend
    )
    VALUES (
        @StartDate, YEAR(@StartDate), MONTH(@StartDate), DAY(@StartDate),
        DATEPART(WEEKDAY, @StartDate), DATENAME(WEEKDAY, @StartDate),
        DATENAME(MONTH, @StartDate), DATEPART(QUARTER, @StartDate),
        CASE WHEN DATEPART(WEEKDAY, @StartDate) IN (1, 7) THEN 1 ELSE 0 END
    );

    SET @StartDate = DATEADD(DAY, 1, @StartDate);
END;


