DROP TABLE IF EXISTS dspot.DIM_Fornecedor;

CREATE TABLE dspot.DIM_Fornecedor (
    ID_Fornecedor VARCHAR(10) PRIMARY KEY NOT NULL,
    Nome_Fornecedor VARCHAR(100),
    Email VARCHAR(100),
    Telefone VARCHAR(9),
    Localidade NVARCHAR(100),
    Pais NVARCHAR(100),
    Codigo_postal VARCHAR(100)
);

SELECT * FROM dspot.DIM_Fornecedor;

INSERT INTO dspot.DIM_Fornecedor (
    ID_Fornecedor, Nome_Fornecedor, Email, Telefone, Localidade, Pais, Codigo_Postal
)
VALUES
('FOR1', 'Solu��es Industriais LDA', 'geral@solucoes.pt', '914567890', 'Lisboa', 'Portugal', '1100-001'),
('FOR2', 'Equipamentos T�cnicos LDA', 'contacto@equiptec.pt', '913456789', 'Porto', 'Portugal', '4000-001'),
('FOR3', 'Forniture Tecniche SRL', 'vendite@forniture.it', '913248765', 'Mil�o', 'It�lia', '20121'),
('FOR4', 'Logistica Italia SRL', 'info@logistica.it', '916789123', 'Roma', 'It�lia', '00184'),
('FOR5', 'Tech Supplies Ltd', 'contact@techsupplies.uk', '912345678', 'London', 'Reino Unido', 'SW1A 1AA'),
('FOR6', 'Industrial Solutions Ltd', 'sales@indsol.uk', '917654321', 'Manchester', 'Reino Unido', 'M1 1AE'),
('FOR7', 'Equipements Industriels SA', 'info@equipindus.fr', '914567890', 'Paris', 'Fran�a', '75008'),
('FOR8', 'Logistique Pro SA', 'contact@logistique.fr', '915678234', 'Marselha', 'Fran�a', '13001'),
('FOR9', 'Technische Lieferungen GmbH', 'info@techlieferungen.de', '918234567', 'Berlim', 'Alemanha', '10115'),
('FOR10', 'Industrialbedarf AG', 'kontakt@industrial.de', '919876543', 'Munique', 'Alemanha', '80333'),
('FOR11', 'Proveedores del Norte SL', 'contacto@proveedores.es', '916543987', 'Madrid', 'Espanha', '28001'),
('FOR12', 'Log�stica Ib�rica SL', 'ventas@logistica.es', '917890654', 'Barcelona', 'Espanha', '08001'),
('FOR13', 'Supplies Europe BV', 'sales@supplies.nl', '913457829', 'Amesterd�o', 'Pa�ses Baixos', '1011AB'),
('FOR14', 'Holland Logistics BV', 'info@hollandlogistics.nl', '918765432', 'Roterd�o', 'Pa�ses Baixos', '3011AA'),
('FOR15', 'Solutions Techniques LDA', 'info@solutions.pt', '917654298', 'Coimbra', 'Portugal', '3000-001'),
('FOR16', 'Distribuidora Nacional LDA', 'contacto@distribuidora.pt', '919872345', 'Faro', 'Portugal', '8000-001'),
('FOR17', 'T�cnica Avan�ada LDA', 'info@tecnica.pt', '914327896', 'Braga', 'Portugal', '4700-001'),
('FOR18', 'Equipamentos Avan�ados LDA', 'contacto@equipav.pt', '916783452', '�vora', 'Portugal', '7000-001'),
('FOR19', 'Acess�rios Industriais LDA', 'geral@acessind.pt', '912398745', 'Viseu', 'Portugal', '3500-001'),
('FOR20', 'Svenska Leverant�rer AB', 'info@leverantorer.se', '917890654', 'Estocolmo', 'Su�cia', '11122'),
('FOR21', 'Europ�ische Versorgung AG', 'kontakt@versorgung.ch', '915678234', 'Zurique', 'Su��a', '8001'),
('FOR22', 'Distribuidores Polonia Sp. z o.o.', 'biuro@distribuidores.pl', '916543987', 'Vars�via', 'Pol�nia', '00-001'),
('FOR23', 'Hellas Supplies AE', 'epikoinonia@hellassupplies.gr', '919234876', 'Atenas', 'Gr�cia', '10557'),
('FOR24', 'Nordic Provisions Oy', 'contact@nordicprovisions.fi', '917654298', 'Helsinki', 'Finl�ndia', '00100'),
('FOR25', 'Danmark Leverancer ApS', 'kontakt@leverancer.dk', '919872345', 'Copenhaga', 'Dinamarca', '1000'),
('FOR26', 'Baltic Resources SIA', 'info@balticresources.lv', '913457829', 'Riga', 'Let�nia', 'LV-1050'),
('FOR27', 'Luxembourg Services SA', 'contact@services.lu', '919872345', 'Luxemburgo', 'Luxemburgo', 'L-1510'),
('FOR28', 'Czechia Suppliers s.r.o.', 'info@suppliers.cz', '914327896', 'Praga', 'Rep�blica Checa', '110 00'),
('FOR29', 'Lithuanian Products UAB', 'info@products.lt', '912398745', 'V�lnius', 'Litu�nia', '01109'),
('FOR30', 'Estonian Logistics OU', 'kontakt@logistics.ee', '917654298', 'Tallinn', 'Est�nia', '10115'),
('FOR31', 'Irish Supplies Ltd', 'sales@irishsupplies.ie', '913248765', 'Dublin', 'Irlanda', 'D02'),
('FOR32', 'Belgium Partners NV', 'info@partners.be', '918765432', 'Bruxelas', 'B�lgica', '1000'),
('FOR33', 'Norwegian Trade AS', 'kontakt@trade.no', '919872345', 'Oslo', 'Noruega', '0152'),
('FOR34', 'Maltese Supplies Ltd', 'info@supplies.mt', '913457829', 'Valeta', 'Malta', 'VLT 1110'),
('FOR35', 'Tech Supplies Switzerland AG', 'info@techswiss.ch', '918234567', 'Genebra', 'Su��a', '1201');
