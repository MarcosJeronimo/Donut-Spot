CREATE TABLE dspot.DIM_Local_Venda(
	ID_Local VARCHAR(10) PRIMARY KEY NOT NULL,
	Nome NVARCHAR(100) NOT NULL,
	Data_Inicio DATE,
	Data_Fim DATE,
	Localizacao NVARCHAR(100),
	ID_Funcionario VARCHAR(10) NOT NULL);

INSERT INTO dspot.DIM_Local_Venda (ID_Local, Nome, Data_Inicio, Data_Fim, Localizacao, ID_Funcionario)
VALUES 
	('LV1', 'Mercado da Ribeira', '2024-05-01', '2024-05-05', 'Lisboa', 'F12'),
	('LV2', 'Mercado do Bolh�o', '2024-06-01', '2024-06-04', 'Porto', 'F13'),
	('LV3', 'Festival da Sardinha', '2024-07-10', '2024-07-16', 'Portim�o', 'F14'),
	('LV4', 'Feira das Latas', '2024-08-15', '2024-08-20', 'Coimbra', 'F15');





