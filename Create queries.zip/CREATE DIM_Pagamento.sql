CREATE TABLE dspot.DIM_Pagamento(
	ID_Pagamento VARCHAR(10) PRIMARY KEY NOT NULL,
	Metodo_Pagamento NVARCHAR(100) NOT NULL);

INSERT INTO dspot.DIM_Pagamento (ID_Pagamento, Metodo_Pagamento)
VALUES
	('P1', 'Dinheiro'),
	('P2', 'MBWay'),
	('P3', 'Multibanco');