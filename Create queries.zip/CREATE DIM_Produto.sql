CREATE TABLE dspot.DIM_Produto(
	ID_Produto VARCHAR(10) PRIMARY KEY NOT NULL,
	Nome_produto NVARCHAR(100),
	Categoria VARCHAR(100),
	Preco_Produto NUMERIC(10,2)
);
-- ID_Materia_Prima como chave estrangeira para adicionar depois

INSERT INTO dspot.DIM_Produto (
    ID_Produto, Nome_Produto, Categoria, Preco_Produto)
VALUES
('PROD1', 'Donut Cl�ssico de Chocolate com Cobertura de Baunilha', 'Cl�ssico', '3.50'),
('PROD2', 'Donut de Morango com Granulados Coloridos', 'Sazonal', '4.00'),
('PROD3', 'Donut Premium de Pistache e Chocolate Branco', 'Premium', '6.00'),
('PROD4', 'Donut de Caramelo com Cobertura de Nozes', 'Premium', '5.50'),
('PROD5', 'Donut Cl�ssico de Lim�o', 'Cl�ssico', '3.80'),
('PROD6', 'Donut Vegano de Frutas Tropicais', 'Sazonal', '5.00'),
('PROD7', 'Donut Integral de Sementes e Mel', 'Cl�ssico', '4.50'),
('PROD8', 'Donut de Amendoim com Cobertura de Caramelo', 'Premium', '5.80'),
('PROD9', 'Donut de Chocolate Branco com Framboesa', 'Sazonal', '5.50'),
('PROD10', 'Donut Proteico de Caf� e Whey', 'Premium', '6.00'),
('PROD11', 'Donut Tradicional de Baunilha', 'Cl�ssico', '3.50'),
('PROD12', 'Donut de Lim�o com Geleia de Maracuj�', 'Sazonal', '4.20'),
('PROD13', 'Donut de Morango com Chocolate Meio Amargo', 'Premium', '5.70'),
('PROD14', 'Donut de Coco com Doce de Leite', 'Cl�ssico', '4.00'),
('PROD15', 'Donut de Nozes com Cobertura de Mel', 'Premium', '5.90'),
('PROD16', 'Donut de Pistache com Creme de Lim�o', 'Sazonal', '5.50'),
('PROD17', 'Donut Integral com Cobertura de Am�ndoas', 'Cl�ssico', '4.50'),
('PROD18', 'Donut de Avel� com Chocolate ao Leite', 'Premium', '5.80'),
('PROD19', 'Donut de Frutas Vermelhas', 'Sazonal', '4.70'),
('PROD20', 'Donut de Canela com A��car Mascavo', 'Cl�ssico', '3.80');