CREATE TABLE dspot.Produto_Materia_Prima (
	ID_Produto VARCHAR(10) NOT NULL,
	ID_Materia_Prima VARCHAR(10) NOT NULL,
	FOREIGN KEY (ID_Produto) REFERENCES dspot.DIM_Produto(ID_Produto),
	FOREIGN KEY (ID_Materia_Prima) REFERENCES dspot.DIM_Materia_Prima(ID_Materia_Prima));

INSERT INTO dspot.Produto_Materia_Prima (ID_Produto, ID_Materia_Prima)
VALUES
('PROD1', 'MP7'), ('PROD1', 'MP17'), ('PROD1', 'MP16'),
('PROD2', 'MP8'), ('PROD2', 'MP14'), ('PROD2', 'MP3'),
('PROD3', 'MP43'), ('PROD3', 'MP38'), ('PROD3', 'MP13'),
('PROD4', 'MP39'), ('PROD4', 'MP9'), ('PROD4', 'MP25'),
('PROD5', 'MP32'), ('PROD5', 'MP10'), ('PROD5', 'MP5'),
('PROD6', 'MP48'), ('PROD6', 'MP35'), ('PROD6', 'MP23'),
('PROD7', 'MP30'), ('PROD7', 'MP22'), ('PROD7', 'MP19'),
('PROD8', 'MP20'), ('PROD8', 'MP39'), ('PROD8', 'MP9'),
('PROD9', 'MP38'), ('PROD9', 'MP37'), ('PROD9', 'MP15'),
('PROD10', 'MP50'), ('PROD10', 'MP31'), ('PROD10', 'MP25'),
('PROD11', 'MP17'), ('PROD11', 'MP3'), ('PROD11', 'MP10'),
('PROD12', 'MP32'), ('PROD12', 'MP48'), ('PROD12', 'MP35'),
('PROD13', 'MP8'), ('PROD13', 'MP25'), ('PROD13', 'MP43'),
('PROD14', 'MP39'), ('PROD14', 'MP9'), ('PROD14', 'MP20'),
('PROD15', 'MP9'), ('PROD15', 'MP39'), ('PROD15', 'MP25'),
('PROD16', 'MP43'), ('PROD16', 'MP32'), ('PROD16', 'MP9'),
('PROD17', 'MP30'), ('PROD17', 'MP19'), ('PROD17', 'MP10'),
('PROD18', 'MP43'), ('PROD18', 'MP25'), ('PROD18', 'MP38'),
('PROD19', 'MP37'), ('PROD19', 'MP15'), ('PROD19', 'MP3'),
('PROD20', 'MP15'), ('PROD20', 'MP3'), ('PROD20', 'MP9');