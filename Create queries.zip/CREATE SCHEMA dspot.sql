CREATE SCHEMA dspot;

SELECT * 
FROM sys.schemas
WHERE name = 'dspot';

