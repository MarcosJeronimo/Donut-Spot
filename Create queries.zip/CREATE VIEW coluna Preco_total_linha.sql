CREATE VIEW dspot.Vw_FAC_Linhas_Vendas AS
SELECT
	flv. *,
	flv.Quantidade * pto.Preco_Produto AS Preco_total_linha
FROM
	dspot.FAC_Linhas_Vendas AS flv
JOIN
	dspot.DIM_Producao AS prod ON flv.ID_Producao = prod.ID_Producao
JOIN
	dspot.DIM_Produto AS pto ON prod.ID_Produto = pto.ID_Produto;


SELECT *
FROM dspot.Vw_FAC_Linhas_Vendas