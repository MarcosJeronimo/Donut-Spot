CREATE SCHEMA dspot;  -- Create a custom schema
GO



CREATE TABLE dspot.DIM_Cliente (
    ID_Cliente NUMERIC(4) NOT NULL PRIMARY KEY,
    Nome VARCHAR(255) NOT NULL,
    Email VARCHAR(255),
    Telefone VARCHAR(9),
    Morada VARCHAR(255),
    Concelho VARCHAR(255),
    Contribuinte VARCHAR(9),
    Tipo_Cliente VARCHAR(255)
);


INSERT INTO dspot.DIM_Cliente
VALUES (1, 'Ze Miguel', 'zemiguel@gmail.com', '91212212', 'Rua das ruas 23', 'Lisboa', '200111222', 'Premium');

INSERT INTO dspot.DIM_Cliente
VALUES (2, 'Ze Miguel', 'zemiguel@gmail.com', '91212212', 'Rua das ruas 23', 'Lisboa', '200111222', 'Premium'),
	(3, 'Ze Miguel', 'zemiguel@gmail.com', '91212212', 'Rua das ruas 23', 'Lisboa', '200111222', 'Premium');

SELECT * FROM dspot.DIM_Cliente;